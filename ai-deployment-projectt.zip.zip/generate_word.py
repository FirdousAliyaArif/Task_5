from docx import Document

def create_word_report(filename="deployment_report.docx"):
    doc = Document()
    
    # Document Title & Metadata
    doc.add_heading('AI Model Deployment & Monitoring Report', 0)
    doc.add_paragraph('Author: AI Engineering Team  |  Version: 1.0.0  |  Date: November 2026')
    
    # Section 1
    doc.add_heading('1. Executive Summary & Architecture Overview', level=1)
    doc.add_paragraph(
        'This documentation outlines the end-to-end containerized deployment of a machine learning prediction service. '
        'By migrating from an offline Jupyter notebook prototype to an isolated FastAPI microservice packaged within a Docker container, '
        'we ensure reproducible execution, clean interface decoupling, and robust observability.'
    )
    
    # Section 2
    doc.add_heading('2. Containerization & Environment Configuration', level=1)
    doc.add_paragraph(
        'The service is containerized using a multi-layered Dockerfile built on top of a lightweight Python 3.10 slim image. '
        'System dependencies required for compiling scientific libraries are provisioned during build time, while application requirements '
        'are installed cleanly via pip with cache disabled to minimize final image size.'
    )
    
    # Section 3
    doc.add_heading('3. API Design & Endpoints Specification', level=1)
    doc.add_paragraph(
        'The API is constructed using FastAPI, leveraging Pydantic models for strict type enforcement and automatic input/output validation. '
        'Key endpoints include:\n'
        '• GET /health: Liveness probe returning status and active state for orchestrator health monitoring.\n'
        '• POST /predict: Accepts structured feature payloads, executes mock model inference, and returns predicted outputs alongside confidence scores and execution latency.'
    )
    
    # Section 4
    doc.add_heading('4. Logging, Monitoring & Observability Strategies', level=1)
    doc.add_paragraph(
        'Observability is handled via custom HTTP middleware that intercepts requests to record timestamps, paths, HTTP methods, '
        'response codes, and precise execution durations down to the millisecond. Logs are streamed to standard out in a structured format '
        'compatible with container log aggregation systems.'
    )
    
    # Section 5
    doc.add_heading('5. Discussion: Best Practices in AI Deployment & Maintenance', level=1)
    doc.add_paragraph(
        'Bridging the gap between offline data science experimentation and online production reliability requires adherence to rigorous MLOps standards. '
        'Deployed AI services face challenges distinct from traditional software, including numerical drift, latency spikes, and silent feature degradation.\n\n'
        'Health Checks and Liveness Probes: Implementing granular health checks separates application liveness from service readiness, '
        'preventing load balancers from routing traffic to degraded pods.\n\n'
        'Handling Concept Drift: Continuous monitoring of input feature distributions and implementing fallback mechanisms ensures '
        'graceful degradation if model confidence plummets.'
    )
    
    # Save document
    doc.save(filename)
    print(f"Word report successfully generated: {filename}")

if __name__ == "__main__":
    create_word_report()