import time
import logging
from fastapi import FastAPI, Request, HTTPException
from pydantic import BaseModel

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(levelname)s - %(message)s",
)
logger = logging.getLogger("ai-service")

app = FastAPI(title="AI Model Serving & Monitoring PoC", version="1.0.0")

class PredictionRequest(BaseModel):
    feature_1: float
    feature_2: float
    category_id: int

class PredictionResponse(BaseModel):
    prediction: float
    confidence: float
    latency_ms: float

@app.middleware("http")
async def log_requests(request: Request, call_next):
    start_time = time.time()
    response = await call_next(request)
    duration = (time.time() - start_time) * 1000
    logger.info(f"Path: {request.url.path} | Method: {request.method} | Status: {response.status_code} | Duration: {duration:.2f}ms")
    return response

@app.post("/predict", response_model=PredictionResponse)
def predict(payload: PredictionRequest):
    start_time = time.time()
    try:
        mock_prediction = (payload.feature_1 * 0.5) + (payload.feature_2 * 0.3) + payload.category_id
        mock_confidence = 0.89
        
        latency = (time.time() - start_time) * 1000
        logger.info(f"Prediction successful. Input: {payload.model_dump()} | Output: {mock_prediction}")
        
        return {
            "prediction": round(mock_prediction, 4),
            "confidence": mock_confidence,
            "latency_ms": round(latency, 2)
        }
    except Exception as e:
        logger.error(f"Inference error: {str(e)}")
        raise HTTPException(status_code=500, detail="Internal model inference error.")

@app.get("/health")
def health_check():
    return {"status": "healthy", "service": "active"}