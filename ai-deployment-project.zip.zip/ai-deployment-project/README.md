# AI Model Deployment & Monitoring PoC

This project demonstrates a proof-of-concept deployment of a containerized AI service using FastAPI, Docker, and structured request logging.

## Project Structure
- `app/main.py`: FastAPI application, prediction endpoints, and logging middleware.
- `Dockerfile`: Container image configuration file.
- `requirements.txt`: Python package dependencies.

## How to Run Locally

1. **Build the Docker Image:**
   ```bash
   docker build -t ai-model-service:v1 .